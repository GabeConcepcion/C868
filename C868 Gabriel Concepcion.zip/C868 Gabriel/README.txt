Title: Concepcion Scheduling - Appointment Scheduler

Purpose: GUI-based application to schedule appointments, manage customer and appointment data, and present reports.
         The information is retrieved and stored from a database.

Author: Gabriel Concepcion 005408844

Contact Information: Email: gconce3@wgu.edu
                     Phone: (860) 987-2858

Application Version: 1.0

Date: 5/31/2025

IDE: IntelliJ IDEA Community Edition 2024.3.2.1
JDK: Java SE 17.0.1
JavaFX version compatible: 17.0.1
MySQL version: 8.0.26
---------------------------------------------------------------------------------------------------------------------------

Program Instructions: Run main to start the application. The login screen will appear. 
Credentials:Enter "admin" for username and "admin" for password to login. Login info "test" and "test" will also work.
The application will then display the main menu where you can access the Appointments, Customers, and Reports screens.

The additional report added is in the "Reports" screen "Appointments By Country" tab.
The report shows the number of appointments per country in a table.

---------------------------------------------------------------------------------------------------------------------------

 
Standalone JavaFX application.
 
Inheritance Example: IdentifiableEntity. Extended by Appointments, Customers, Contacts, Users.
 
Polymorphism Example: generateTextReportHandler. Demonstrates polymorphism by displaying details of different entity types.
 
Encapsulation: MVC architecture, private fields, public getters/setters, etc.
 
Search Functionality: Implemented in AppointmentController and CustomersController.
 
Database component: JDBC class for database connection and queries, DAO classes, MySQL.
 
Generate Reports: ReportController class and reports screen.
 
Exception controls: Try-Catch blocks for error handling such as SQLExceptions.
 
Validation Functionality: Input validation for appointment, customer information, and user login.
 
Industry Appropriate Security Feature: Input validation for login credentials and SQL Injection Prevention.
 
Scalable Design: Elements are scrollable (table views, combo boxes) and contents are handled by MySQL database.

---------------------------------------------------------------------------------------------------------------------------
Main Run Configuration VM Options:
--module-path ${PATH_TO_FX} --add-modules javafx.fxml,javafx.controls,javafx.graphics
VM Database:
Username: sqlUser
port: 3306
Password: Passw0rd!
Database Name: client_schedule
