package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customers;
import model.Users;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

/**
 * CustomerDB class to handle database operations for Customer objects.
 * Provides methods to retrieve, add, update, and delete customer records.
 */
public class CustomerDB {

    /**
     * Retrieves all customers from the database along with their division name.
     * Populates customer selection ComboBoxes.
     * 
     * @return ObservableList of all customers.
     */
    public static ObservableList<Customers> getAllCustomers() {
        ObservableList<Customers> customerList = FXCollections.observableArrayList();
        // Joining with first_level_divisions to get the division name
        String sql = "SELECT c.*, d.Division FROM customers c JOIN first_level_divisions d ON c.Division_ID = d.Division_ID";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerPostalCode = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division"); // Get division name from the join

                Customers customer = new Customers(customerID, customerName, customerAddress, customerPostalCode, customerPhone, divisionID, divisionName);
                customerList.add(customer);
            }
        } catch (SQLException e) {
            System.out.println("Error getting all customers: " + e.getMessage());
            e.printStackTrace();
        }
        return customerList;
    }

    /**
     * Retrieves count of appointments grouped by country.
     * Used for appointment and country report.
     
     * @return map with country names as keys and appointment counts as values.
     * @throws SQLException if a database access error occurs.
     */
    public static Map<String, Integer> getAppointmentCountByCountry() throws SQLException {
    Map<String, Integer> countryCounts = new HashMap<>();
    String sql = "SELECT co.Country, COUNT(a.Appointment_ID) as count " +
                "FROM appointments a " +
                "JOIN customers c ON a.Customer_ID = c.Customer_ID " +
                "JOIN first_level_divisions d ON c.Division_ID = d.Division_ID " +
                "JOIN countries co ON d.Country_ID = co.Country_ID " +
                "GROUP BY co.Country";
    
    try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            countryCounts.put(rs.getString("Country"), rs.getInt("count"));
        }
    }
    return countryCounts;
}

    /**
     * Adds a new customer intto the database.
     * 
     * @param customer Customer object to add.
     * @return true if the customer was added successfully, else false
     */
    public static boolean addCustomer(Customers customer) {
        String sql = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES (?, ?, ?, ?, NOW(), ?, NOW(), ?, ?)";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getCustomerAddress());
            ps.setString(3, customer.getCustomerPostalCode());
            ps.setString(4, customer.getCustomerPhone());
            String currentUser = Users.getCurrentUserName();
            ps.setString(5, currentUser);
            ps.setString(6, currentUser);
            ps.setInt(7, customer.getDivisionID());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error adding customer: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Updates an existing customer in the database.
     * 
     * @param customer Customer object with updated customer information.
     * @return true if the customer was updated successfully, else false.
     */
    public static boolean updateCustomer(Customers customer) {
        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Last_Update = NOW(), Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getCustomerAddress());
            ps.setString(3, customer.getCustomerPostalCode());
            ps.setString(4, customer.getCustomerPhone());
            String currentUser = Users.getCurrentUserName();
            ps.setString(5, currentUser);
            ps.setInt(6, customer.getDivisionID());
            ps.setInt(7, customer.getId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Deletes a customer from the database by their ID.
     * Automatically deletes all associated appointments first.
     * 
     * @param customerId ID of customer to delete.
     * @return true if the customer and their appointments were deleted successfully, else false.
     * @throws SQLException if a database access error occurs
     */
    public static boolean deleteCustomer(int customerId) throws SQLException {
        // First, delete all appointments for this customer
        try {
            if (!AppointmentDB.deleteAppointmentsByCustomerId(customerId)) {
                System.out.println("No appointments found for customer " + customerId + ", deleting customer.");
            }
            
            // Then delete the customer
            String sql = "DELETE FROM customers WHERE Customer_ID = ?";
            try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
                ps.setInt(1, customerId);
                int rowsAffected = ps.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            System.out.println("Error deleting customer " + customerId + ": " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
}
