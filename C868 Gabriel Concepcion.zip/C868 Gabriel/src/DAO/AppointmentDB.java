package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointments;
import model.Users;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * AppointmentDB class to handle database operations for Appointment objects.
 * Provides methods to retrieve, add, update, and delete appointments.
 * Checks for scheduling conflicts.
 */
public class AppointmentDB {

    /**
     * Retrieves all appointments from the database with contact information.
     *
     * @return ObservableList with all appointments
     * @throws SQLException if a database access error occurs
     */
    public static ObservableList<Appointments> getAllAppointments() throws SQLException {
        ObservableList<Appointments> allAppointments= FXCollections.observableArrayList();
        String sqlQuery = "SELECT a.*, c.Contact_Name FROM APPOINTMENTS a JOIN CONTACTS c ON a.Contact_ID = c.Contact_ID";
        PreparedStatement ps = JDBC.connection.prepareStatement(sqlQuery);
        ResultSet rs = ps.executeQuery();

        while(rs.next()){
            int appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");

            Timestamp Start=rs.getTimestamp("Start");
            LocalDateTime start=Start.toLocalDateTime();

            Timestamp End=rs.getTimestamp("End");
            LocalDateTime end=End.toLocalDateTime();

            int customerID = rs.getInt("Customer_ID");
            int userID = rs.getInt("User_ID");
            int contactID = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");

            Appointments appointment = new Appointments(appointmentId, title, description, location, type, start, end,
                    customerID, userID, contactID);
            appointment.setContactName(contactName);
            allAppointments.add(appointment);
        }
        return allAppointments;
    }

    /**
     * Retrieves all appointments for a specific customer.
     * Used to check if a customer has any appointments before allowing deletion.
     *
     * @param customerId customer ID to get appointments for
     * @return ObservableList with Appointments for the selected customer
     * @throws SQLException if a database access error occurs
     */
    public static ObservableList<Appointments> getAppointmentsByCustomerId(int customerId) throws SQLException {
        ObservableList<Appointments> customerAppointments = FXCollections.observableArrayList();
        String sqlQuery = "SELECT a.*, c.Contact_Name FROM APPOINTMENTS a JOIN CONTACTS c ON a.Contact_ID = c.Contact_ID WHERE a.Customer_ID = ?";
        
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sqlQuery)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentId = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");

                Appointments appointment = new Appointments(appointmentId, title, description, location, type, 
                start, end, customerId, userID, contactID);
                appointment.setContactName(contactName);
                customerAppointments.add(appointment);
            }
        }
        return customerAppointments;
    }
    
    /**
     * Inserts a new appointment into the database.
     *
     * @param appointment Appointments object containing appointment information
     * @return true if the appointment was added successfully, else false
     */
    public static boolean addAppointment(Appointments appointment) {
        String sql = "INSERT INTO APPOINTMENTS (Appointment_ID, Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, NOW(), ?, ?, ?, ?)";
        try {
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ps.setInt(1, appointment.getId());
            ps.setString(2, appointment.getAppointmentTitle());
            ps.setString(3, appointment.getAppointmentDescription());
            ps.setString(4, appointment.getAppointmentLocation());
            ps.setString(5, appointment.getAppointmentType());
            ps.setTimestamp(6, Timestamp.valueOf(appointment.getStart()));
            ps.setTimestamp(7, Timestamp.valueOf(appointment.getEnd()));
            String currentUser = Users.getCurrentUserName();
            ps.setString(8, currentUser);
            ps.setString(9, currentUser);
            ps.setInt(10, appointment.getCustomerID());
            ps.setInt(11, appointment.getUserID());
            ps.setInt(12, appointment.getContactID());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
        catch (SQLException e) {
            System.out.println("Error adding appointment: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Updates an existing appointment in the database.
     *
     * @param appointment Appointments object with updated information
     * @return true if the appointment was updated successfully, else false
     * @throws SQLException if a database access error occurs
     */
    public static boolean updateAppointment(Appointments appointment) throws SQLException {
        String sql = "UPDATE APPOINTMENTS SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Last_Update = NOW(), Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sql)) {
            ps.setString(1, appointment.getAppointmentTitle());
            ps.setString(2, appointment.getAppointmentDescription());
            ps.setString(3, appointment.getAppointmentLocation());
            ps.setString(4, appointment.getAppointmentType());
            ps.setTimestamp(5, Timestamp.valueOf(appointment.getStart()));
            ps.setTimestamp(6, Timestamp.valueOf(appointment.getEnd()));
            String currentUser = Users.getCurrentUserName();
            ps.setString(7, currentUser);
            ps.setInt(8, appointment.getCustomerID());
            ps.setInt(9, appointment.getUserID());
            ps.setInt(10, appointment.getContactID());
            ps.setInt(11, appointment.getId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    /**
     * Deletes an appointment from the database.
     *
     * @param appointmentId ID of the appointment to delete
     * @return true if the appointment was deleted successfully, else false
     * @throws SQLException if a database access error occurs
     */
    public static boolean deleteAppointment(int appointmentId) throws SQLException {
        String sql = "DELETE FROM APPOINTMENTS WHERE Appointment_ID = ?";
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    /**
     * Deletes all appointments for a specific customer.
     *
     * @param customerId customer ID whose appointments should be deleted
     * @return true if the appointments were deleted successfully, else false
     * @throws SQLException if a database access error occurs
     */
    public static boolean deleteAppointmentsByCustomerId(int customerId) throws SQLException {
        String sql = "DELETE FROM APPOINTMENTS WHERE Customer_ID = ?";
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    /**
     * Checks if a customer has any overlapping appointments during the specified time range.
     * Prevents scheduling conflicts when adding or updating appointments.
     *
     * @param start start time of appointment
     * @param end end time of appointment
     * @param excludeAppointmentId ID of appointment to exclude from check (for updates)
     * @return true if there is an overlapping appointment, else false
     * @throws SQLException if a database access error occurs
     */
    public static boolean hasOverlappingAppointment(LocalDateTime start, LocalDateTime end, int excludeAppointmentId) throws SQLException {
        String sql = "SELECT COUNT(*) AS overlap_count FROM APPOINTMENTS " +
                   "WHERE (" +
                   "  (Start < ? AND End > ?) " +      // Existing appointment starts before and ends after new appointment starts
                   "  OR (Start < ? AND End > ?) " +     // Existing appointment starts before new appointment ends and ends after
                   "  OR (Start >= ? AND Start < ?) " +   // Existing appointment starts during new appointment
                   "  OR (End > ? AND End <= ?) " +      // Existing appointment ends during new appointment
                   "  OR (Start <= ? AND End >= ?) " +   // New appointment is completely within existing appointment
                   ")";
        
        if (excludeAppointmentId > 0) {
            sql += " AND Appointment_ID != ?";
        }
        
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sql)) {
            int appointmentIndex = 1;
            
            // First condition: (Start < ? AND End > ?)
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(end));    // Start < new end
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(start)); // End > new start
            
            // Second condition: (Start < ? AND End > ?)
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(end));    // Start < new end
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(start)); // End > new start
            
            // Third condition: (Start >= ? AND Start < ?)
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(start)); // Start >= new start
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(end));   // Start < new end
            
            // Fourth condition: (End > ? AND End <= ?)
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(start)); // End > new start
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(end));   // End <= new end
            
            // Fifth condition: (Start <= ? AND End >= ?)
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(start)); // Start <= new start
            ps.setTimestamp(appointmentIndex++, Timestamp.valueOf(end));   // End >= new end
            
            if (excludeAppointmentId > 0) {
                ps.setInt(appointmentIndex, excludeAppointmentId);
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("overlap_count") > 0;
                }
                return false;
            }
        }
    }

    /**
     * Retrieves appointments that are within 15 minutes of the current time for a specific user.
     * Used to display upcoming appointment notifications.
     *
     * @param userId ID of user to check appointments for
     * @return ObservableList of upcoming appointments within 15 minutes, empty list if none found
     * @throws SQLException if a database access error occurs
     */
    public static ObservableList<Appointments> getUpcomingAppointments(int userId) throws SQLException {
        ObservableList<Appointments> upcomingAppointments = FXCollections.observableArrayList();
        LocalDateTime now = LocalDateTime.now(ZoneId.of("UTC"));
        LocalDateTime fifteenMinutesLater = now.plusMinutes(15);
        
        String sql = "SELECT a.*, c.Contact_Name FROM APPOINTMENTS a " +
                   "JOIN CONTACTS c ON a.Contact_ID = c.Contact_ID " +
                   "WHERE a.User_ID = ? AND (" +
                   "  (a.Start BETWEEN ? AND ?) " +  // Starting within next 15 minutes
                   "  OR (a.Start <= ? AND a.End >= ?)" +  // Already started but not ended
                   ")";
        
        try (PreparedStatement ps = JDBC.connection.prepareStatement(sql)) {
            ps.setInt(1, userId);
            // Starting between now and 15 minutes from now
            ps.setTimestamp(2, Timestamp.valueOf(now));
            ps.setTimestamp(3, Timestamp.valueOf(fifteenMinutesLater));
            // Already started but not ended
            ps.setTimestamp(4, Timestamp.valueOf(now));
            ps.setTimestamp(5, Timestamp.valueOf(now));
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                int appointmentId = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int customerId = rs.getInt("Customer_ID");
                int contactId = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                
                Appointments appointment = new Appointments(
                    appointmentId, title, description, location, type, 
                    start, end, customerId, userId, contactId
                );
                appointment.setContactName(contactName);
                upcomingAppointments.add(appointment);
            }
        }
        
        return upcomingAppointments;
    }

    /**
     * Retrieves all appointments for a specific contact.
     * Used in the contact schedule in the Reports screen.
     * 
     * @param contactId ID of contact to get appointments for
     * @return ObservableList of Appointments for selected contact
     * @throws SQLException if a database access error occurs
     */
    public static ObservableList<Appointments> getAppointmentsByContact(int contactId) throws SQLException {
        ObservableList<Appointments> appointments = FXCollections.observableArrayList();
        String sql = "SELECT a.*, c.Contact_Name " +
                    "FROM appointments a " +
                    "JOIN contacts c ON a.Contact_ID = c.Contact_ID " +
                    "WHERE a.Contact_ID = ? " +
                    "ORDER BY a.Start";
        
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setInt(1, contactId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int appointmentId = rs.getInt("Appointment_ID");
                    String title = rs.getString("Title");
                    String description = rs.getString("Description");
                    String location = rs.getString("Location");
                    String type = rs.getString("Type");
                    LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                    int customerId = rs.getInt("Customer_ID");
                    int userId = rs.getInt("User_ID");
                    String contactName = rs.getString("Contact_Name");
                    
                    Appointments appointment = new Appointments(
                        appointmentId, title, description, location, type,
                        start, end, customerId, userId, contactId
                    );
                    appointment.setContactName(contactName);
                    appointments.add(appointment);
                }
            }
        }
        return appointments;
    }
}
