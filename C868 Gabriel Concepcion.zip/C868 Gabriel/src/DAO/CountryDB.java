package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Country;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * CountryDB class to handle database operations for Country objects.
 * Provides methods to retrieve all countries from the database.
 */
public class CountryDB {

    /**
     * Retrieves all countries from the database.
     * Populates country selection ComboBoxes.
     * 
     * @return ObservableList of all countries.
     */
    public static ObservableList<Country> getAllCountries() {
        ObservableList<Country> countryList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM countries";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int countryID = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Country country = new Country(countryID, countryName);
                countryList.add(country);
            }
        } catch (SQLException e) {
            System.out.println("Error getting all countries: " + e.getMessage());
            e.printStackTrace();
        }
        return countryList;
    }
}
