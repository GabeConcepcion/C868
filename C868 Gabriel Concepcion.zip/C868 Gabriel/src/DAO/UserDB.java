package DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Users;
import helper.JDBC;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * UserDB class to handle database operations for User objects.
 * Provides methods to validate user credentials and retrieve user information.
 */
public class UserDB extends Users {

    /**
     * Constructor for UserDB.
     * 
     * @param userID user ID.
     * @param userName user name.
     * @param userPassword user password.
     */
    public UserDB(int userID, String userName, String userPassword) {
        super(userID, userName, userPassword);
    }

    /**
     * Validates the user login details with database for the login form.
     * Industry Appropriate Security Feature: SQL Injection Prevention.
     * @param username user name to validate
     * @param password user password to validate
     * @return user ID if validation is successful, 0 otherwise.
     */
    public static int validateUser(String username, String password) {
        String sql = "SELECT User_ID FROM users WHERE User_Name = ? AND Password = ?";
        
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("User_ID");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error validating user: " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Retrieves all users from the database.
     * Populates user selection ComboBoxes.
     * 
     * @return ObservableList of all Users.
     * @throws SQLException if a database access error occurs
     */
    public static ObservableList<Users> getAllUsers() throws SQLException {
        ObservableList<Users> userList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM users";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String userPassword = rs.getString("Password");
                Users user = new Users(userID, userName, userPassword);
                userList.add(user);
            }
        } catch (SQLException e) {
            System.out.println("Error getting all users: " + e.getMessage());
            e.printStackTrace();
        }
        return userList;
    }
}

