package model;

/**
 * FirstLevelDivision class to represent first-level division data.
 * Contains division information.
 */
public class FirstLevelDivision {
    private int divisionID;
    private String divisionName;
    private int divisionCountryID;

    /**
     * FirstLevelDivision constructor.
     *
     * @param divisionID divison ID
     * @param divisionName divison name
     * @param divisionCountryID divison country ID
     */
    public FirstLevelDivision(int divisionID, String divisionName, int divisionCountryID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.divisionCountryID = divisionCountryID;
    }

    /**
     * Gets division ID.
     *
     * @return division ID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     * Sets division ID.
     *
     * @param divisionID division ID
     */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    /**
     * Gets division name.
     *
     * @return division name
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * Sets division name.
     *
     * @param divisionName division name
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    /**
     * Gets division country ID.
     *
     * @return division country ID
     */
    public int getDivisionCountryID() {
        return divisionCountryID;
    }

    /**
     * Sets division country ID.
     *
     * @param divisionCountryID division country ID
     */
    public void setDivisionCountryID(int divisionCountryID) {
        this.divisionCountryID = divisionCountryID;
    }
}