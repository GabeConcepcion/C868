package model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Appointments class to represent appointment data.
 * Provides methods to get and set appointment properties.
 */
public class Appointments extends IdentifiableEntity {
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentType;
    private LocalDateTime start;
    private LocalDateTime end;
    private int customerID;
    private int userID;
    private int contactID;

    private String contactName;

    public Appointments(int appointmentID, String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType, LocalDateTime start, LocalDateTime end, int customerID, int userID, int contactID) {
        super(appointmentID);
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentType = appointmentType;
        this.start = start;
        this.end = end;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }

    /**
     * Gets appointment title.
     * 
     * @return appointment title
     */
    public String getAppointmentTitle() {
        return appointmentTitle;
    }

    /**
     * Sets appointment title.
     * 
     * @param appointmentTitle appointment title
     */
    public void setAppointmentTitle(String appointmentTitle) {
        this.appointmentTitle = appointmentTitle;
    }

    /**
     * Gets appointment description.
     * 
     * @return appointment description
     */
    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    /**
     * Sets appointment description.
     * 
     * @param appointmentDescription appointment description
     */
    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }

    /**
     * Gets appointment location.
     * 
     * @return appointment location
     */
    public String getAppointmentLocation() {
        return appointmentLocation;
    }

    /**
     * Sets appointment location.
     * 
     * @param appointmentLocation appointment location
     */
    public void setAppointmentLocation(String appointmentLocation) {
        this.appointmentLocation = appointmentLocation;
    }

    /**
     * Gets appointment type.
     * 
     * @return appointment type
     */
    public String getAppointmentType() {
        return appointmentType;
    }

    /**
     * Sets appointment type.
     * 
     * @param appointmentType appointment type
     */
    public void setAppointmentType(String appointmentType) {
        this.appointmentType = appointmentType;
    }

    /**
     * Gets appointment start time.
     * 
     * @return appointment start time
     */
    public LocalDateTime getStart() {
        return start;
    }

    /**
     * Sets appointment start time.
     * 
     * @param start appointment start time
     */
    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    /**
     * Gets appointment end time.
     * 
     * @return appointment end time
     */
    public LocalDateTime getEnd() {
        return end;
    }

    /**
     * Sets appointment end time.
     * 
     * @param end appointment end time
     */
    public void setEnd(LocalDateTime end) {
        this.end = end;
    }

    /**
     * Gets customer ID.
     * 
     * @return customer ID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * Sets customer ID.
     * 
     * @param customerID customer ID
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     * Gets user ID.
     * 
     * @return user ID
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets user ID.
     * 
     * @param userID user ID
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Gets contact ID.
     * 
     * @return contact ID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * Sets contact ID.
     * 
     * @param contactID contact ID
     */
    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    /**
     * Gets contact name.
     * 
     * @return contact name
     */
    public String getContactName() { 
        return contactName; 
    }
    /**
     * Sets contact name.
     * 
     * @param contactName contact name
     */
    public void setContactName(String contactName) {
        this.contactName = contactName; 
    }

    /**
     * Gets start time formatted in the local timezone.
     * Converts from UTC to system default timezone.
     *
     * @return formatted start date and time string (MM/dd/yyyy hh:mm a)
     */
    public String getStartLocalFormatted() {
        return start.atZone(ZoneId.of("UTC"))
                   .withZoneSameInstant(ZoneId.systemDefault())
                   .format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a"));
    }

    /**
     * Gets end time formatted in the local timezone.
     * Converts from UTC to system default timezone.
     *
     * @return formatted end date and time string (MM/dd/yyyy hh:mm a)
     */
    public String getEndLocalFormatted() {
        return end.atZone(ZoneId.of("UTC"))
                 .withZoneSameInstant(ZoneId.systemDefault())
                 .format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a"));
    }

    @Override
    public String getName() {
        return String.format("Appointment: %s (Type: %s)", appointmentTitle, appointmentType);
    }

    @Override
    public String getDetails() {
    return String.format("Appointment #%d: %s (Type: %s, %s to %s)", 
        getId(), 
        getAppointmentTitle(), 
        getAppointmentType(),
        getStart().format(DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a")),
        getEnd().format(DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a")));
}
}
