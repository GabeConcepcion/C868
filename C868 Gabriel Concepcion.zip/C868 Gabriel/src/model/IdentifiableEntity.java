package model;

/**
 * Inheritance to Appointments, Contacts, Customers, Users:
 * Abstract base class for entities that have an ID.
 * "is-a" relationship. For example, a customer is an IdentifiableEntity.
 * If necessary to change how IDs are handled in the future, this class can be extended.
 */
public abstract class IdentifiableEntity {
    protected int id;

    /**
     * Constructor for IdentifiableEntity.
     * @param id entity id.
     */
    public IdentifiableEntity(int id) {
        this.id = id;
    }

    /**
     * Gets the unique identifier of the entity.
     * @return entity id.
     */
    public int getId() {
        return id;
    }

    /**
     * Gets name or title of the entity.
     * Implemented by subclasses.
     * @return entity name/title.
     */
    public abstract String getName();

    /**
     * Displays entity detail information.
     * This method demonstrates polymorphism as each subclass will implement it differently.
     * @return entity details string
     */
    public String getDetails() {
        return String.format("ID: %d, Name: %s", getId(), getName());
    }
}
