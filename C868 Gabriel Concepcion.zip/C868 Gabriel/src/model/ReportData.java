package model;

/**
 * ReportData class to represent report data.
 * Contains data for generating different types of reports.
 */
public class ReportData {
    private final String type;
    private final String month;
    private final String country;
    private final int count;

    /**
     * Constructor for type/month report data.
     *
     * @param type the type of appointment
     * @param month the month of the appointment
     * @param count the count of appointments
     */
    public ReportData(String type, String month, int count) {
        this.type = type;
        this.month = month;
        this.count = count;
        this.country = null;
    }

    /**
     * Constructor for country report data.
     *
     * @param count the count of appointments
     * @param country the country of the appointments
     * @param unused unused (constructor overload)
     */
    public ReportData(int count, String country, String unused) {
        this.country = country;
        this.type = null;
        this.month = unused;
        this.count = count;
    }

    /**
     * Gets the appointment type.
     *
     * @return the appointment type
     */
    public String getType() {
        return type;
    }

    /**
     * Gets the month.
     *
     * @return the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Gets the count.
     *
     * @return the count
     */
    public int getCount() {
        return count;
    }
}