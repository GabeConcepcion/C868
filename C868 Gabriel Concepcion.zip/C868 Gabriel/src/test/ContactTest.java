package test;

import model.Contacts;

public class ContactTest {

    public static void testContactsMethods() {
        System.out.println("Running testContactsMethods:");
        
        int expectedId = 1;
        String expectedName = "Anika Patel";
        String expectedEmail = "anika.patel@example.com";
        
        Contacts contact = new Contacts(expectedId, expectedName, expectedEmail);

        // ID (from IdentifiableEntity)
        int actualId = contact.getId();
        if (expectedId == actualId) {
            System.out.println("  getId(): PASSED");
        } else {
            System.err.println("  getId(): FAILED. Expected " + expectedId + ", but got " + actualId);
        }

        // Contact Name
        String actualName = contact.getContactName();
        if (expectedName.equals(actualName)) {
            System.out.println("  getContactName(): PASSED");
        } else {
            System.err.println("  getContactName(): FAILED. Expected '" + expectedName + "', but got '" + actualName + "'");
        }

        // Contact Email
        String actualEmail = contact.getContactEmail();
        if (expectedEmail.equals(actualEmail)) {
            System.out.println("  getContactEmail(): PASSED");
        } else {
            System.err.println("  getContactEmail(): FAILED. Expected '" + expectedEmail + "', but got '" + actualEmail + "'");
        }

        // toString()
        String toStringResult = contact.toString();
        if (expectedName.equals(toStringResult)) {
            System.out.println("  toString(): PASSED (should return contactName)");
        } else {
            System.err.println("  toString(): FAILED. Expected '" + expectedName + "', but got '" + toStringResult + "'");
        }
        System.out.println("---");
    }

    public static void main(String[] args) {
        System.out.println("Starting Contacts tests:");
        testContactsMethods();
        System.out.println("Contacts tests finished.");
    }
}