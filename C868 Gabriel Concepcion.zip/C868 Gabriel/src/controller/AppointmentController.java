package controller;

import DAO.AppointmentDB;
import DAO.ContactDB; 
import DAO.CustomerDB; 
import DAO.UserDB;     
import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments; 
import model.Contacts;   
import model.Customers;  
import model.Users;       

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * AppointmentController class to create the appointment screen UI and functionality.
 * Handles creating, reading, updating, and deleting appointments with time zone conversions
 * and validations.
 */
public class AppointmentController implements Initializable {

    // Table View and Columns
    @FXML private TableView<Appointments> appointmentTable;
    @FXML private TableColumn<Appointments, Integer> appointmentIDCol;
    @FXML private TableColumn<Appointments, String> appointmentTitleCol;
    @FXML private TableColumn<Appointments, String> appointmentDescriptionCol;
    @FXML private TableColumn<Appointments, String> appointmentLocationCol;
    @FXML private TableColumn<Appointments, String> appointmentTypeCol;
    @FXML private TableColumn<Appointments, String> appointmentStartCol; 
    @FXML private TableColumn<Appointments, String> appointmentEndCol;   
    @FXML private TableColumn<Appointments, Integer> appointmentCustomerIdCol;
    @FXML private TableColumn<Appointments, Integer> appointmentUserIdCol;
    @FXML private TableColumn<Appointments, String> appointmentContactIdCol; 

    // Radio Buttons to filter appointments
    @FXML private RadioButton weekRadioButton;
    @FXML private RadioButton monthRadioButton;
    @FXML private RadioButton allRadioButton;
    @FXML private ToggleGroup timelength;

    // Form Fields
    @FXML private TextField appointmentIdField; 
    @FXML private TextField appointmentTitleField; 
    @FXML private TextField appointmentDescriptionField; 
    @FXML private TextField appointmentLocationField; 
    @FXML private TextField appointmentTypeField; 
    @FXML private ComboBox<Contacts> contactIdComboBox; 
    @FXML private DatePicker startDatePicker;
    @FXML private ComboBox<LocalTime> startTimeComboBox;
    @FXML private DatePicker endDatePicker; 
    @FXML private ComboBox<LocalTime> endTimeComboBox;
    @FXML private ComboBox<Customers> customerIdComboBox; 
    @FXML private ComboBox<Users> userIdComboBox; 
    @FXML private Button saveButton; 
    @FXML private Button cancelButton; 
    @FXML private TextField searchField;

    // Main Action Buttons
    @FXML private Button addAppointmentButton;
    @FXML private Button modifyAppointmentButton;
    @FXML private Button deleteAppointmentButton;
    @FXML private Button menuButton;
    @FXML private Button exitButton;

    private ObservableList<Appointments> allAppointmentsList = FXCollections.observableArrayList();
    private Appointments selectedAppointment = null; 
    private boolean isUpdateMode = false; // Adding or updating

    // Time Zone constants
    private final ZoneId localZoneId = ZoneId.systemDefault();  // User's local time zone
    private final ZoneId etZoneId = ZoneId.of("America/New_York");  // Eastern Time (ET)
    private final ZoneId utcZoneId = ZoneId.of("UTC");  // UTC for database storage
    private final LocalTime businessStartET = LocalTime.of(8, 0);
    private final LocalTime businessEndET = LocalTime.of(22, 0);

    /**
     * Initializes AppointmentController class.
     * Sets table columns, loads appointment data, and form controls.
     * 
     * @param url
     * @param rb 
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize main appointment table columns
        appointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        appointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentStartCol.setCellValueFactory(new PropertyValueFactory<>("startLocalFormatted"));
        appointmentEndCol.setCellValueFactory(new PropertyValueFactory<>("endLocalFormatted"));
        appointmentCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("userID"));
        appointmentContactIdCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));

        loadAllAppointments(); 
        appointmentTable.setItems(allAppointmentsList);

        // Sort appointment table by ID in ascending order
        appointmentTable.getSortOrder().add(appointmentIDCol);
        appointmentIDCol.setSortType(TableColumn.SortType.ASCENDING);

        // Set initial state for form fields (disabled until Add/Update is clicked)
        setFormFieldsDisabled(true);

        // Initialize Form Elements
        try {
            contactIdComboBox.setItems(ContactDB.getAllContacts());
            contactIdComboBox.setConverter(new javafx.util.StringConverter<Contacts>() {
                @Override
                public String toString(Contacts contact) {
                    return contact == null ? "" : String.valueOf(contact.getId());
                }

                @Override
                public Contacts fromString(String idString) {
                    if (idString == null || idString.isEmpty()) return null;
                    int id = Integer.parseInt(idString);
                    return contactIdComboBox.getItems().stream().filter(c ->
                     c.getId() == id).findFirst().orElse(null);
                }
            });
            // Set a StringConverter to display customer ID
            if (customerIdComboBox != null) {
                customerIdComboBox.setItems(CustomerDB.getAllCustomers());
                customerIdComboBox.setConverter(new javafx.util.StringConverter<Customers>() {
                    @Override
                    public String toString(Customers customer) {
                        return customer == null ? "" : String.valueOf(customer.getId());
                    }

                    @Override
                    public Customers fromString(String idString) {
                        if (idString == null || idString.isEmpty()) return null;
                        int id = Integer.parseInt(idString);
                        return customerIdComboBox.getItems().stream().filter(c -> 
                        c.getId() == id).findFirst().orElse(null);
                    }
                });
            }
            // Set a StringConverter to display user ID
            if (userIdComboBox != null) {
                userIdComboBox.setItems(UserDB.getAllUsers());
                userIdComboBox.setConverter(new javafx.util.StringConverter<Users>() {
                    @Override
                    public String toString(Users user) {
                        return user == null ? "" : String.valueOf(user.getId());
                    }

                    @Override
                    public Users fromString(String idString) {
                        if (idString == null || idString.isEmpty()) return null;
                        int id = Integer.parseInt(idString);
                        return userIdComboBox.getItems().stream().filter(u -> 
                        u.getId() == id).findFirst().orElse(null);
                    }
                });
            }
            // 15-minute intervals for a 24-hour period
            ObservableList<LocalTime> times = FXCollections.observableArrayList();
            LocalTime time = LocalTime.MIN;
            for (int i = 0; i < 24 * 4; i++) { 
                times.add(time);
                time = time.plusMinutes(15);
            }
            if (startTimeComboBox != null) startTimeComboBox.setItems(times);
            if (endTimeComboBox != null) endTimeComboBox.setItems(times);
            if (appointmentIdField != null) appointmentIdField.setDisable(true);

        } catch (SQLException e) {
            System.err.println("Error initializing form ComboBoxes: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            if (e.getMessage() != null) e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Form Initialization Error");
            alert.setHeaderText(null);
            alert.setContentText("Error loading form data.");
            alert.showAndWait();
        } catch (Exception e) {
            System.err.println("Unexpected error initializing form: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            if (e.getMessage() != null) e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Form Initialization Error");
            alert.setHeaderText(null);
            alert.setContentText("Unexpected error initializing form.");
            alert.showAndWait();
        }
        
        // Add event handler for search field
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            searchAppointments();
        });
        
    }

    /**
     * Loads all appointments from the database and displays them in the table.
     * Sorts the appointments by ID in ascending order.
     */
    private void loadAllAppointments() {
        try {
            allAppointmentsList.setAll(AppointmentDB.getAllAppointments());
            // Sort appointment table by ID in ascending order
            appointmentTable.getSortOrder().add(appointmentIDCol);
            appointmentIDCol.setSortType(TableColumn.SortType.ASCENDING);
        } catch (SQLException e) {
            System.err.println("Error loading appointments: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            if (e.getMessage() != null) e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Database Error");
            alert.setHeaderText(null);
            alert.setContentText("Could not load appointments from the database.");
            alert.showAndWait();
        }
    }

    /**
     * Refreshes the appointment table by loading appointments based on radio button filters.
     * If no filter is selected, loads all appointments.
     */
    private void refreshAppointmentTable() {
        loadAllAppointments();
        if (timelength != null && timelength.getSelectedToggle() != null) {
            Toggle selectedToggle = timelength.getSelectedToggle();
            if (selectedToggle == weekRadioButton) filterAppointmentsByWeek();
            else if (selectedToggle == monthRadioButton) filterAppointmentsByMonth();
            else appointmentTable.setItems(allAppointmentsList);
        } else {
            appointmentTable.setItems(allAppointmentsList);
        }
    }

    /**
     * Handler for the All radio button selection.
     * Shows all appointments in the table.
     * 
     * @param event allRadioButton clicked
     */
    @FXML 
    void appointmentAllSelectHandler(ActionEvent event) {
        searchField.clear();
        appointmentTable.setItems(allAppointmentsList);}
    
    /**
     * Handler for the Week radio button selection.
     * Filters and shows appointments for the current week.
     * 
     * @param actionEvent weekRadioButton clicked
     */
    @FXML 
    void appointmentWeekSelectHandler(ActionEvent actionEvent) {filterAppointmentsByWeek();}
    
    /**
     * Handler for the Month radio button selection.
     * Filters and shows appointments for the current month.
     * 
     * @param actionEvent monthRadioButton clicked
     */
    @FXML 
    void appointmentMonthSelectHandler(ActionEvent actionEvent) {filterAppointmentsByMonth();}
    

    /**
     * Handler for the Add Appointment button.
     * Initializes the form for adding a new appointment.
     * 
     * @param event addAppointmentButton clicked
     */
    @FXML
    void addAppointmentHandler(ActionEvent event) {
        isUpdateMode = false;
        selectedAppointment = null;
        clearFormFields();
        setFormFieldsDisabled(false);
        appointmentIdField.setText("Auto-Generated"); // Indicate ID is auto-gen
        appointmentIdField.setDisable(true); // Ensure ID field remains disabled
        appointmentTitleField.requestFocus(); // Set focus to the first editable field
    }

    /**
     * Handler for the Modify Appointment button.
     * Initializes the form for modifying an existing appointment.
     * 
     * @param event modifyAppointmentButton clicked
     */
    @FXML
    void modifyAppointmentHandler(ActionEvent event) {
        selectedAppointment = appointmentTable.getSelectionModel().getSelectedItem();
        if (selectedAppointment != null) {
            isUpdateMode = true;
            setFormFieldsDisabled(false);
            populateFormWithAppointment(selectedAppointment);
            appointmentIdField.setDisable(true);
            appointmentTitleField.requestFocus();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText(null);
            alert.setContentText("Please select an appointment to update.");
            alert.showAndWait();
        }
    }
    
    /**
     * Handler for the Delete Appointment button.
     * Deletes the selected appointment from the database.
     * 
     * @param event deleteAppointmentButton clicked
     */
    @FXML
    void deleteAppointmentHandler(ActionEvent event) {
        Appointments selectedAppointment = appointmentTable.getSelectionModel().getSelectedItem();
        if (selectedAppointment == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText(null);
            alert.setContentText("Please select an appointment to delete.");
            alert.showAndWait();
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Deletion");
        confirmation.setHeaderText("Delete Appointment ID: " + selectedAppointment.getId());
        confirmation.setContentText("Are you sure you want to delete appointment ID: " + selectedAppointment.getId() +
                                  " of type '" + selectedAppointment.getAppointmentType() + "'?");
        Optional<ButtonType> result = confirmation.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                boolean success = AppointmentDB.deleteAppointment(selectedAppointment.getId());
                if (success) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Appointment deleted");
                    alert.setHeaderText(null);
                    alert.setContentText("Appointment " + selectedAppointment.getId() +
                                      " (" + selectedAppointment.getAppointmentType() + ") has been successfully deleted.");
                    alert.showAndWait();
                    refreshAppointmentTable();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Deletion Failed");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to delete appointment.");
                    alert.showAndWait();
                }
            } catch (SQLException e) {
                System.err.println("Database error during deletion: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
                if (e.getMessage() != null) e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Database Error");
                alert.setHeaderText(null);
                alert.setContentText("Failed to delete appointment.");
                alert.showAndWait();
            }
        }
    }

    /**
     * Populates form fields with the selected appointment's information.
     * 
     * @param appointment appointment information for form
     */
    private void populateFormWithAppointment(Appointments appointment) {
        appointmentIdField.setText(String.valueOf(appointment.getId()));
        appointmentTitleField.setText(appointment.getAppointmentTitle());
        appointmentDescriptionField.setText(appointment.getAppointmentDescription());
        appointmentLocationField.setText(appointment.getAppointmentLocation());
        appointmentTypeField.setText(appointment.getAppointmentType());

        if (contactIdComboBox != null) {
            contactIdComboBox.getItems().stream()
                .filter(contact -> contact.getId() == appointment.getContactID()) 
                .findFirst().ifPresent(contactIdComboBox::setValue);
        }
        if (customerIdComboBox != null) {
            customerIdComboBox.getItems().stream()
                .filter(customer -> customer.getId() == appointment.getCustomerID()) 
                .findFirst().ifPresent(customerIdComboBox::setValue);
        }
        if (userIdComboBox != null) {
            userIdComboBox.getItems().stream()
                .filter(user -> user.getId() == appointment.getUserID()) 
                .findFirst().ifPresent(userIdComboBox::setValue);
        }

        LocalDateTime startUTC = appointment.getStart();
        LocalDateTime endUTC = appointment.getEnd();
        if (startUTC != null && startDatePicker != null && startTimeComboBox != null) {
            ZonedDateTime startLocal = startUTC.atZone(utcZoneId).withZoneSameInstant(localZoneId);
            startDatePicker.setValue(startLocal.toLocalDate());
            startTimeComboBox.setValue(startLocal.toLocalTime());
        }
        if (endUTC != null && endDatePicker != null && endTimeComboBox != null) {
            ZonedDateTime endLocal = endUTC.atZone(utcZoneId).withZoneSameInstant(localZoneId);
            endDatePicker.setValue(endLocal.toLocalDate());
            endTimeComboBox.setValue(endLocal.toLocalTime());
        }
        // Sort appointment table by ID in ascending order
        appointmentTable.getSortOrder().add(appointmentIDCol);
        appointmentIDCol.setSortType(TableColumn.SortType.ASCENDING);
    }

    /**
     * Handler for the Save Appointment button.
     * Validates input, appointment time, and  checks for changes before saving the appointment to the database.
     * 
     * @param event saveButton clicked
     */
    @FXML
    void saveButtonHandler(ActionEvent event) {
        if (!validateInput()) return;

        try {
            // Create appointment from form data
            String title = appointmentTitleField.getText().trim();
            String description = appointmentDescriptionField.getText().trim();
            String location = appointmentLocationField.getText().trim();
            String type = appointmentTypeField.getText().trim();
            
            int customerId = customerIdComboBox.getValue().getId();
            int userId = userIdComboBox.getValue().getId();
            int contactId = contactIdComboBox.getValue().getId();
            
            // Convert local times to UTC for storage and overlap checking
            ZonedDateTime localStart = LocalDateTime.of(startDatePicker.getValue(), startTimeComboBox.getValue()).atZone(localZoneId);
            ZonedDateTime localEnd = LocalDateTime.of(endDatePicker.getValue(), endTimeComboBox.getValue()).atZone(localZoneId);
            
            // Convert to UTC for database operations
            ZonedDateTime utcStart = localStart.withZoneSameInstant(ZoneOffset.UTC);
            ZonedDateTime utcEnd = localEnd.withZoneSameInstant(ZoneOffset.UTC);
            
            if (!validateAppointmentTimes(localStart.toLocalDateTime(), localEnd.toLocalDateTime())) return;
            
            if (isUpdateMode && selectedAppointment != null) {
                // Check if changes were made
                boolean hasChanges = !selectedAppointment.getAppointmentTitle().equals(title) ||
                                  !selectedAppointment.getAppointmentDescription().equals(description) ||
                                  !selectedAppointment.getAppointmentLocation().equals(location) ||
                                  !selectedAppointment.getAppointmentType().equals(type) ||
                                  selectedAppointment.getCustomerID() != customerId ||
                                  selectedAppointment.getUserID() != userId ||
                                  selectedAppointment.getContactID() != contactId ||
                                  !selectedAppointment.getStart().equals(utcStart.toLocalDateTime()) ||
                                  !selectedAppointment.getEnd().equals(utcEnd.toLocalDateTime());
                
                if (!hasChanges) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("No Changes");
                    alert.setHeaderText(null);
                    alert.setContentText("No changes were made.");
                    alert.showAndWait();
                    return;
                }
                // Update existing appointment
                selectedAppointment.setAppointmentTitle(title);
                selectedAppointment.setAppointmentDescription(description);
                selectedAppointment.setAppointmentLocation(location);
                selectedAppointment.setAppointmentType(type);
                selectedAppointment.setStart(utcStart.toLocalDateTime());
                selectedAppointment.setEnd(utcEnd.toLocalDateTime());
                selectedAppointment.setCustomerID(customerId);
                selectedAppointment.setUserID(userId);
                selectedAppointment.setContactID(contactId);
                
                if (AppointmentDB.hasOverlappingAppointment(utcStart.toLocalDateTime(), utcEnd.toLocalDateTime(), selectedAppointment.getId())) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("The modified appointment overlaps with an existing appointment.");
                    alert.showAndWait();
                    return;
                }
                
                if (AppointmentDB.updateAppointment(selectedAppointment)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText(String.format("Appointment ID: %d updated successfully.", selectedAppointment.getId()));
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to update appointment.");
                    alert.showAndWait();
                }
            } else {
                // Create new appointment
                Appointments newAppointment = new Appointments(
                    0, // ID will be set by database
                    title, 
                    description, 
                    location, 
                    type, 
                    utcStart.toLocalDateTime(), 
                    utcEnd.toLocalDateTime(),
                    customerId,
                    userId,
                    contactId
                );
                
                if (AppointmentDB.hasOverlappingAppointment(utcStart.toLocalDateTime(), utcEnd.toLocalDateTime(), 0)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("The new appointment overlaps with an existing appointment.");
                    alert.showAndWait();
                    return;
                }
                
                if (AppointmentDB.addAppointment(newAppointment)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Appointment created successfully.");
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to create appointment.");
                    alert.showAndWait();
                }
            }
            
            // Refresh table and reset form
            loadAllAppointments();
            cancelButtonHandler(null);
            
        } catch (Exception e) {
            System.err.println("Error in saveButtonHandler: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            if (e.getMessage() != null) e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Save Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to save appointment: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            alert.showAndWait();
        }
    }
    
    /**
     * Validates the input fields for the appointment form.
     * 
     * @return true if all required fields are filled, else false
     */
    private boolean validateInput() {
        StringBuilder errors = new StringBuilder();
        if (appointmentTitleField == null || appointmentTitleField.getText().trim().isEmpty()) errors.append("Title is required.\n");
        if (appointmentDescriptionField == null || appointmentDescriptionField.getText().trim().isEmpty()) errors.append("Description is required.\n");
        if (appointmentLocationField == null || appointmentLocationField.getText().trim().isEmpty()) errors.append("Location is required.\n");
        if (appointmentTypeField == null || appointmentTypeField.getText().trim().isEmpty()) errors.append("Type is required.\n");
        if (contactIdComboBox == null || contactIdComboBox.getValue() == null) errors.append("Contact is required.\n");
        if (startDatePicker == null || startDatePicker.getValue() == null) errors.append("Start Date is required.\n");
        if (startTimeComboBox == null || startTimeComboBox.getValue() == null) errors.append("Start Time is required.\n");
        if (endDatePicker == null || endDatePicker.getValue() == null) errors.append("End Date is required.\n");
        if (endTimeComboBox == null || endTimeComboBox.getValue() == null) errors.append("End Time is required.\n");
        if (customerIdComboBox == null || customerIdComboBox.getValue() == null) errors.append("Customer is required.\n");
        if (userIdComboBox == null || userIdComboBox.getValue() == null) errors.append("User is required.\n");
        // If there are validation errors, show them and return false
        if (errors.length() > 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString().trim());
            alert.showAndWait();
            return false;
        }
        return true;
    }
    
    /**
     * Validates the appointment times.
     * 
     * @param localStart start time of the appointment
     * @param localEnd end time of the appointment
     * @return true if the start time is before end time, within business hours, and not on a weekend, else false
     */
    private boolean validateAppointmentTimes(LocalDateTime localStart, LocalDateTime localEnd) {
        if (localStart.isAfter(localEnd) || localStart.isEqual(localEnd)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Time Validation Error");
            alert.setHeaderText(null);
            alert.setContentText("End time must be after start time.");
            alert.showAndWait();
            return false;
        }

        ZonedDateTime etStart = localStart.atZone(localZoneId).withZoneSameInstant(etZoneId);
        ZonedDateTime etEnd = localEnd.atZone(localZoneId).withZoneSameInstant(etZoneId);

        if (etStart.toLocalTime().isBefore(businessStartET) || etEnd.toLocalTime().isAfter(businessEndET) ||
            etStart.toLocalTime().isAfter(businessEndET) || etEnd.toLocalTime().isBefore(businessStartET)) {
            String msg = "Appointment must be within business hours (8:00 AM - 10:00 PM ET).";
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Business Hours Error");
            alert.setHeaderText(null);
            alert.setContentText(msg);
            alert.showAndWait();
            return false;
        }
        if (etStart.getDayOfWeek() == DayOfWeek.SATURDAY || etStart.getDayOfWeek() == DayOfWeek.SUNDAY ||
           etEnd.getDayOfWeek() == DayOfWeek.SATURDAY || etEnd.getDayOfWeek() == DayOfWeek.SUNDAY) {
            String msg = "Appointments cannot be scheduled on weekends (ET).";
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Weekend Scheduling Error");
            alert.setHeaderText(null);
            alert.setContentText(msg);
            alert.showAndWait();
            return false;
        }
        return true;
    }
    
    /**
     * Handler for the Cancel button.
     * Clears bottom gridpane form fields.
     * 
     * @param event cancelButton clicked
     */
    @FXML
    void cancelButtonHandler(ActionEvent event) {
        clearFormFields();
    }

    /**
     * Clears bottom gridpane form fields.
     */
    private void clearFormFields() {
        appointmentIdField.clear();
        appointmentTitleField.clear();
        appointmentDescriptionField.clear();
        appointmentLocationField.clear();
        appointmentTypeField.clear();
        contactIdComboBox.setValue(null);
        startDatePicker.setValue(null);
        startTimeComboBox.setValue(null);
        endDatePicker.setValue(null);
        endTimeComboBox.setValue(null);
        customerIdComboBox.setValue(null);
        userIdComboBox.setValue(null);
    }

    /**
     * Disables or enables all gridpane form fields based on the disable parameter.
     * Appointment ID field is always disabled.
     * 
     * @param disable true to disable fields, false to enable fields
     */
    private void setFormFieldsDisabled(boolean disable) {
        appointmentIdField.setDisable(true);
        appointmentTitleField.setDisable(disable);
        appointmentDescriptionField.setDisable(disable);
        appointmentLocationField.setDisable(disable);
        appointmentTypeField.setDisable(disable);
        startDatePicker.setDisable(disable);
        endDatePicker.setDisable(disable);
        startTimeComboBox.setDisable(disable);
        endTimeComboBox.setDisable(disable);
        customerIdComboBox.setDisable(disable);
        userIdComboBox.setDisable(disable);
        contactIdComboBox.setDisable(disable);
        saveButton.setDisable(disable);
        cancelButton.setDisable(disable);
    }

    /**
     * Filters appointments by the current week.
     */
    private void filterAppointmentsByWeek() {
        searchField.clear();
        LocalDate today = LocalDate.now();
        LocalDate startOfWeek = today.with(DayOfWeek.MONDAY);
        LocalDate endOfWeek = startOfWeek.plusDays(6);
        filterAppointmentsByDateRange(startOfWeek, endOfWeek);
    }

    /**
     * Filters appointments by the current month.
     */
    private void filterAppointmentsByMonth() {
        searchField.clear();
        LocalDate today = LocalDate.now();
        YearMonth currentMonth = YearMonth.from(today);
        LocalDate startOfMonth = currentMonth.atDay(1);
        LocalDate endOfMonth = currentMonth.atEndOfMonth();
        filterAppointmentsByDateRange(startOfMonth, endOfMonth);
    }
    
    /**
     * Filters appointments by a date range by creating an empty observable list
     * and adding appointments that fall within the range. Loops through each appointment
     * in the main list and checks if the appointment has a valid start time.
     * Converts appointment UTC start time to local time.
     * 
     * @param startDate start date range
     * @param endDate end date range
     */
    private void filterAppointmentsByDateRange(LocalDate startDate, LocalDate endDate) {
        ObservableList<Appointments> filteredAppointments = FXCollections.observableArrayList();
        
        for (Appointments app : allAppointmentsList) {
            if (app.getStart() != null) {
                ZonedDateTime utcStart = app.getStart().atZone(utcZoneId);
                ZonedDateTime localStart = utcStart.withZoneSameInstant(localZoneId);
                LocalDate appStartDate = localStart.toLocalDate();
                
                if (!appStartDate.isBefore(startDate) && !appStartDate.isAfter(endDate)) {
                    filteredAppointments.add(app);
                }
            }
        }
        appointmentTable.setItems(filteredAppointments);
    }

    /**
     * Handles the search functionality for appointments.
     * Filters the appointment table based on the search text (ID or title).
     */
    @FXML
    private void searchAppointments() {
        String searchText = searchField.getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            // Check which filter is active and re-apply it
            if (weekRadioButton != null && weekRadioButton.isSelected()) {
                filterAppointmentsByWeek();
            } else if (monthRadioButton != null && monthRadioButton.isSelected()) {
                filterAppointmentsByMonth();
            } else if (allRadioButton != null && allRadioButton.isSelected()) {
                appointmentTable.setItems(allAppointmentsList);
            } else {
                // Default to all
                appointmentTable.setItems(allAppointmentsList);
            }
            return;
        }
        
        ObservableList<Appointments> filteredList = FXCollections.observableArrayList();
        ObservableList<Appointments> sourceListToSearch = appointmentTable.getItems();
        
        for (Appointments appointment : sourceListToSearch) {
            // Ensure appointment and its title are not null before calling methods on them
            if (appointment != null) {
                boolean idMatches = String.valueOf(appointment.getId()).contains(searchText);
                boolean titleMatches = false;
                if (appointment.getAppointmentTitle() != null) {
                    titleMatches = appointment.getAppointmentTitle().toLowerCase().contains(searchText);
                }
                if (idMatches || titleMatches) {
                    filteredList.add(appointment);
                }
            }
        }
        
        appointmentTable.setItems(filteredList);
    }

    /**
     * Handles the Back button action.
     * Navigates back to the main menu screen.
     */
    @FXML
    void menuButtonHandler(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/MenuScreen.fxml"));
            Stage stage = (Stage) menuButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Main Menu");
            stage.show();
        } catch (IOException e) {
            System.out.println("Failed to load Menu Screen: " + e.getMessage());
            e.printStackTrace();
        }
    }
    /**
     * Exit Handler to exit the application with English or French translation.
     */
    @FXML
    void exitButtonHandler() {
        ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(rb.getString("confirmation"));
        alert.setHeaderText(null);
        alert.setContentText(rb.getString("quitAlert"));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }
}
