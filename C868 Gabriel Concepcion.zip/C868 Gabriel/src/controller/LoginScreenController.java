package controller;

import DAO.UserDB;
import DAO.AppointmentDB;
import helper.JDBC;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Users;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * LoginScreenController class to create the login screen UI and functionality.
 */

public class LoginScreenController implements Initializable {

    // Login Screen UI Components
    @FXML private Label loginTitleLbl;
    @FXML private Label usernameFieldLbl;
    @FXML private Label passwordFieldLbl;
    @FXML private TextField loginScreenUsernameTxt;
    @FXML private PasswordField loginScreenPasswordTxt;
    @FXML private TextField loginScreenLocationTxt;
    @FXML private Label locationText;
    @FXML private Button loginButton;
    @FXML private Button exitButton;

    Stage stage;
    ResourceBundle rb;

    /**
     * Initializes LoginScreenController. Get locale and set field text.
     * @param url, rb
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Locale locale = Locale.getDefault();
            Locale.setDefault(locale);
            ZoneId zone = ZoneId.systemDefault();

            // Set location and language
            loginScreenLocationTxt.setText(String.valueOf(zone));
            rb = ResourceBundle.getBundle("language/language", Locale.getDefault());

            loginTitleLbl.setText(rb.getString("scheduler"));
            usernameFieldLbl.setText(rb.getString("username"));
            passwordFieldLbl.setText(rb.getString("password"));
            loginButton.setText(rb.getString("login"));
            exitButton.setText(rb.getString("exit"));
            locationText.setText(rb.getString("location"));

        } catch(MissingResourceException e) {
            System.out.println("Resource file missing: " + e);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     *  Login method for the login screen. Validates user credentials and logs in.
     *  Checks for upcoming appointments and writes to login_activity.txt.
     *  Tracks current user ID and username.
     * 
     * @param event loginButton clicked
     * @throws SQLException
     * @throws IOException
     * @throws Exception
     **/

    @FXML
    private void loginButtonHandler(ActionEvent event) throws SQLException, IOException, Exception {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());

            String usernameInput = loginScreenUsernameTxt.getText();
            String passwordInput = loginScreenPasswordTxt.getText();
            int userId = UserDB.validateUser(usernameInput, passwordInput);

            FileWriter fileWriter = new FileWriter("login_activity.txt", true);
            PrintWriter outputFile = new PrintWriter(fileWriter);

            // Validate username format (alphanumeric and special chars, 3-30 chars)
            if (!usernameInput.matches("^[a-zA-Z0-9._-]{3,30}$")) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(rb.getString("error"));
                alert.setHeaderText(null);
                alert.setContentText(rb.getString("invalidUsername"));
                alert.showAndWait();
                return;
            }

            // Validate password length (4-128 chars)
            if (passwordInput.length() < 4 || passwordInput.length() > 128) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(rb.getString("error"));
                alert.setHeaderText(null);
                alert.setContentText(rb.getString("invalidPassword"));
                alert.showAndWait();
                return;
            }

            if (userId > 0) {
                Users currentUser = new Users(userId, usernameInput, passwordInput);
                Users.setCurrentUser(currentUser);

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/MenuScreen.fxml"));
                Parent root = loader.load();
                stage = (Stage) loginButton.getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setTitle("Main Menu");
                stage.setScene(scene);
                stage.show();

                // Log the successful login
                outputFile.print("user: " + usernameInput + " successfully logged in at: " + Timestamp.valueOf(LocalDateTime.now()) + "\n");

                checkForUpcomingAppointments(userId);
            }
            else if (userId <= 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(rb.getString("error"));
                alert.setContentText(rb.getString("invalid"));
                alert.show();

                // Log the failed login attempt
                outputFile.print("user: " + usernameInput + " failed login: incorrect credentials: " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
            }
            outputFile.close();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    /**
    * Checks for any appointments within the next 15 minutes for the user
    * and shows appropriate alerts.

    * @param userId The ID of the user login
    */
    private void checkForUpcomingAppointments(int userId) {
        try {
        ObservableList<Appointments> upcomingAppointments = AppointmentDB.getUpcomingAppointments(userId);
        
        if (!upcomingAppointments.isEmpty()) {
            // Build the alert message with all upcoming appointments
            StringBuilder message = new StringBuilder(String.format("User ID: %d has the following upcoming or current appointments:\n\n", userId));
            
            for (Appointments appt : upcomingAppointments) {
                message.append(String.format("• ID: %d, %s at %s - %s (User ID: %d)\n",
                    appt.getId(),
                    appt.getAppointmentTitle(),
                    appt.getStartLocalFormatted(),
                    appt.getAppointmentType(),
                    appt.getUserID()
                ));
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Upcoming Appointments");
            alert.setHeaderText(null);
            alert.setContentText(message.toString());
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No Upcoming Appointments");
            alert.setHeaderText(null);
            alert.setContentText("You have no appointments within the next 15 minutes.");
            alert.showAndWait();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    /** Exit Handler to exit the application with English or French translation. */
    @FXML
    void exitButtonHandler() {
        ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(rb.getString("quitAlert"));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }
}
