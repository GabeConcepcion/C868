package model;

/**
 * Users class representing a user of the application.
 * Includes functionality to track the current user.
 */
public class Users extends IdentifiableEntity {
    private String userName;
    private String userPassword;
    
    private static int currentUserID;
    private static String currentUserName;

    /**
     * Default constructor for Users.
     */
    public Users() {
        super(0); // Or -1, or handle as an error if User must have a valid ID
    }

    /**
     * Constructor for Users.
     *
     * @param userID user id
     * @param userName user name
     * @param userPassword user password
     */
    public Users(int userID, String userName, String userPassword) {
        super(userID); // Call to superclass constructor
        this.userName = userName;
        this.userPassword = userPassword;
    }

    /**
     * Gets user name
     *
     * @return user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Gets user password
     *
     * @return user password
     */
    public String getUserPassword() {
        return userPassword;
    }
    
    /**
     * Sets the current user
     *
     * @param user current user
     */
    public static void setCurrentUser(Users user) {
        if (user != null) {
            currentUserID = user.getId(); // Should already be user.getId() from previous change
            currentUserName = user.getUserName(); // Or user.getName() if preferred for consistency
        }
    }
    
    /**
     * Gets current user ID
     *
     * @return current user ID
     */
    public static int getCurrentUserID() {
        return currentUserID;
    }
    
    /**
     * Gets current user's username
     *
     * @return current user's username
     */
    public static String getCurrentUserName() {
        return currentUserName;
    }

    @Override
    public String getName() {
        return this.userName;
    }
}