package model;

/**
 * Contacts class to represent contact data.
 * Contains contact information and methods for display.
 */
public class Contacts extends IdentifiableEntity {
    private String contactName;
    private String contactEmail;

    /**
     * Contacts constructor.
     *
     * @param contactID the unique identifier for the contact
     * @param contactName the name of the contact
     * @param contactEmail the email address of the contact
     */
    public Contacts(int contactID, String contactName, String contactEmail) {
        super(contactID); // Call to superclass constructor
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**
     * Gets contact name.
     *
     * @return contact name
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets contact name.
     *
     * @param contactName contact name
     */
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /**
     * Gets contact email.
     *
     * @return contact email
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * Sets contact email.
     *
     * @param contactEmail contact email
     */
    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    /**
     * Returns the contact name as the string representation.
     * Used for display in ComboBoxes.
     *
     * @return contact name
     */
    @Override
    public String toString() {
        return contactName;
    }

    @Override
    public String getName() {
        return String.format("Contact: %s <%s>", contactName, contactEmail);
    }
}