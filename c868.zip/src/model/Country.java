package model;

/**
 * Country class to represent country data.
 * Contains country information and methods for display.
 */
public class Country {
    private int countryID;
    private String countryName;

    /**
     * Country constructor.
     *
     * @param countryID the unique identifier for the country
     * @param countryName the name of the country
     */
    public Country(int countryID, String countryName) {
        this.countryID = countryID;
        this.countryName = countryName;
    }

    /**
     * Gets country ID.
     *
     * @return country ID
     */
    public int getCountryID() {
        return countryID;
    }

    /**
     * Sets country ID.
     *
     * @param countryID country ID
     */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /**
     * Gets country name.
     *
     * @return country name
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Sets country name.
     *
     * @param countryName country name
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
