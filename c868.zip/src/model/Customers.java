package model;

/**
 * Customers class to represent customer data.
 * Contains customer information.
 */
public class Customers extends IdentifiableEntity {
    private String customerName;
    private String customerAddress;
    private String customerPostalCode;
    private String customerPhone;
    private int divisionID;
    private String divisionName;

    public Customers(int customerID, String customerName, String customerAddress, 
                    String customerPostalCode, String customerPhone, 
                    int divisionID, String divisionName) {
        super(customerID);
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostalCode = customerPostalCode;
        this.customerPhone = customerPhone;
        this.divisionID = divisionID;
        this.divisionName = divisionName;
    }

    /**
     * Gets customer name.
     *
     * @return customer name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Sets customer name.
     *
     * @param customerName customer name
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * Gets customer address.
     *
     * @return customer address
     */
    public String getCustomerAddress() {
        return customerAddress;
    }

    /**
     * Sets customer address.
     *
     * @param customerAddress customer address
     */
    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    /**
     * Gets customer postal code.
     *
     * @return customer postal code
     */
    public String getCustomerPostalCode() {
        return customerPostalCode;
    }

    /**
     * Sets customer postal code.
     *
     * @param customerPostalCode customer postal code
     */
    public void setCustomerPostalCode(String customerPostalCode) {
        this.customerPostalCode = customerPostalCode;
    }

    /**
     * Gets customer phone number.
     *
     * @return customer phone number
     */
    public String getCustomerPhone() {
        return customerPhone;
    }

    /**
     * Sets customer phone number.
     *
     * @param customerPhone customer phone number
     */
    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    /**
     * Gets division ID.
     *
     * @return division ID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     * Sets division ID.
     *
     * @param divisionID division ID
     */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    /**
     * Gets division name.
     *
     * @return division name
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * Sets division name.
     *
     * @param divisionName division name
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    @Override
    public String getName() {
        return String.format("Customer: %s", customerName);
    }
}
