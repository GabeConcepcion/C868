package main;

import helper.JDBC;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Locale;
/** 
 * Standalone JavaFX application.
 * 
 * Inheritance Example: IdentifiableEntity. Extended by Appointments, Customers, Contacts, Users.
 * 
 * Polymorphism Example: generateTextReportHandler. Demonstrates polymorphism by displaying details of different entity types.
 * 
 * Encapsulation: MVC architecture, private fields, public getters/setters, etc.
 * 
 * Search Functionality: Implemented in AppointmentController and CustomersController.
 * 
 * Database component: JDBC class for database connection and queries, DAO classes, MySQL.
 * 
 * Generate Reports: ReportController class and reports screen.
 * 
 * Exception controls: Try-Catch blocks for error handling such as SQLExceptions.
 * 
 * Validation Functionality: Input validation for appointment, customer information, and user login.
 * 
 * Industry Appropriate Security Feature: Input validation for login credentials and SQL Injection Prevention.
 * 
 * Scalable Design: Elements are scrollable (table views, combo boxes) and contents are handled by MySQL database.
 * 
 * Main application class that extends Application.
 * Initializes the JavaFX application and sets up the login screen.
 * @author Gabriel Concepcion 005408844
 */

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/view/LoginScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 360, 360);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Main method to launch the JavaFX application.
     * Uncomment Locale.setDefault(new Locale("fr")); to switch to French.
     * If set to french, startDate and endDate fields are in day/month/year format when adding new information.
     * @param args 
     */
    public static void main(String[] args) {
        JDBC.openConnection();

//        Locale.setDefault(new Locale("fr"));
        launch();
        JDBC.closeConnection();
    }
}