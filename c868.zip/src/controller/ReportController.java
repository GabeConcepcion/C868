package controller;

import DAO.AppointmentDB;
import DAO.ContactDB;
import DAO.CustomerDB;
import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Customers;
import model.IdentifiableEntity;
import model.ReportData;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;

import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.fxml.Initializable;

/**
 * ReportController class to create the reports screen UI and functionality.
 * Handles generating and displaying various reports including contact schedules,
 * appointment types by month, and appointment counts by country.
 */
public class ReportController implements Initializable {

    // Table Views and Columns
    @FXML private ComboBox<Contacts> contactComboBox;
    @FXML private TableView<Appointments> contactScheduleTable;
    @FXML private TableColumn<Appointments, Integer> contactAppointmentIdCol;
    @FXML private TableColumn<Appointments, String> contactAppointmentTitleCol;
    @FXML private TableColumn<Appointments, String> contactAppointmentTypeCol;
    @FXML private TableColumn<Appointments, String> contactAppointmentDescriptionCol;
    @FXML private TableColumn<Appointments, String> contactAppointmentStartCol;
    @FXML private TableColumn<Appointments, String> contactAppointmentEndCol;
    @FXML private TableColumn<Appointments, Integer> contactCustomerIdCol;

    @FXML private TableView<ReportData> typeMonthTable;
    @FXML private TableColumn<ReportData, String> typeCol;
    @FXML private TableColumn<ReportData, String> monthCol;
    @FXML private TableColumn<ReportData, Integer> countCol;
    
    @FXML private TableView<ReportData> countryTable;
    @FXML private TableColumn<ReportData, String> countryCol;
    @FXML private TableColumn<ReportData, Integer> apptCountCol;

    // Main Action Buttons
    @FXML private Button menuButton;
    @FXML private Button exitButton;
    @FXML private TextArea detailsArea;

    /**
     * Initializes the controller class and sets up the UI components.
     * Sets table columns, loads contact data, and cell factories.
     *
     * @param url 
     * @param rb 
     */
    @FXML
    public void initialize(URL url, ResourceBundle rb) {

        // Initialize Contact Schedule table
        contactAppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        contactAppointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        contactAppointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        contactAppointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        contactAppointmentStartCol.setCellValueFactory(new PropertyValueFactory<>("startLocalFormatted"));
        contactAppointmentEndCol.setCellValueFactory(new PropertyValueFactory<>("endLocalFormatted"));
        contactCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        
        // Initialize Type/Month report table
        monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        countCol.setCellValueFactory(new PropertyValueFactory<>("count"));
                
        // Initialize Country report table
        countryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
        apptCountCol.setCellValueFactory(new PropertyValueFactory<>("count"));

        
        // Load contacts
        try {
            contactComboBox.setItems(ContactDB.getAllContacts());
            contactComboBox.setCellFactory(param -> new ListCell<Contacts>() {
                @Override
                protected void updateItem(Contacts item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        setText(item.getContactName());
                    }
                }
            });
            contactComboBox.setButtonCell(new ListCell<Contacts>() {
                @Override
                protected void updateItem(Contacts item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        setText(item.getContactName());
                    }
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the contact schedule table report when a contact is selected and generate schedule is clicked.
     * Displays all appointments for the selected contact in the contact schedule table.
     * Shows a warning if no contact is selected.
     */
    @FXML
    private void generateContactScheduleHandler() {
        Contacts selectedContact = contactComboBox.getSelectionModel().getSelectedItem();
        if (selectedContact == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selection Required");
            alert.setHeaderText(null);
            alert.setContentText("Please select a contact first.");
            alert.showAndWait();
            return;
        }
        
        try {
            ObservableList<Appointments> appointments = AppointmentDB.getAppointmentsByContact(selectedContact.getId());
            contactScheduleTable.setItems(appointments);
            
            // Sort contact schedule table by ID in ascending order
            contactScheduleTable.getSortOrder().add(contactAppointmentIdCol);
            contactAppointmentIdCol.setSortType(TableColumn.SortType.ASCENDING);

        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to generate schedule: " + e.getMessage());
            alert.showAndWait();
        }
    }
    /**
     * Handles the Generate Type/Month Report button action.
     * Generates a report showing the count of unique appointments by type and month 
     * The data is sorted by Total Appointment Count in descending order.
     * 
     * Lambda Justifications:
     * 
     * 1. In Collectors.groupingBy:
     * 
     * Lambda: 
     *   appt -> appt.getAppointmentType() + "|" + Month.from(appt.getStart())
     * 
     * Purpose: Combines appointment by type and month by creating a compound key. Counts occurrences.
     * The pipe "|" character is used as a delimiter to separate the type and month.
     * 
     * Reason: Keeps grouping logic simple and visible where it's used.
     * A separate method is not needed.
     * 
     * 2. In .map:
     * 
     * Lambda:
     *   entry -> {
     *     String[] parts = entry.getKey().split("\\|");
     *     return new ReportData(parts[0], parts[1], entry.getValue().intValue());
     *   }
     * 
     * Purpose: Transforms grouped data into ReportData object by splitting the compound key
     * and extracting the type, month, and count values.
     * 
     * Reason: Encapsulates data transformation logic clearly where it's used. 
     * A separate method is not needed.
     *
     */
    @FXML
    private void generateTypeMonthReportHandler() {
        try {
            // Group appointments by type and month
            Map<String, Long> typeMonthCount = AppointmentDB.getAllAppointments().stream()
                .collect(Collectors.groupingBy(
                    appt -> appt.getAppointmentType() + "|" + Month.from(appt.getStart()), // "Planning Session|MAY"
                    Collectors.counting() // Occurrences of same type and same month
                ));
        
            // Convert to ReportData object
            ObservableList<ReportData> reportData = typeMonthCount.entrySet().stream()
                .map(entry -> {
                    String[] parts = entry.getKey().split("\\|"); // Split to ["Planning Session", "MAY"]
                    return new ReportData(parts[0], parts[1], entry.getValue().intValue()); // Create ReportData object + count
                })
                .collect(Collectors.toCollection(FXCollections::observableArrayList)); // Convert to ObservableList for table
        
            // Update the table
            typeMonthTable.setItems(reportData);
            typeMonthTable.getSortOrder().add(countCol);
            countCol.setSortType(TableColumn.SortType.DESCENDING);
        
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to generate report: " + e.getMessage());
            alert.showAndWait();
        }
    }
    
    /**
     * Handles the country table report generation when generate report is clicked.
     * Displays a count of appointments grouped by country.
     * Sorts the results by appointment count in descending order.
     */
    @FXML
    private void generateCountryReportHandler() {
        try {
            Map<String, Integer> countryCounts = CustomerDB.getAppointmentCountByCountry();
            ObservableList<ReportData> reportData = FXCollections.observableArrayList();
            
            for (Map.Entry<String, Integer> entry : countryCounts.entrySet()) {
                reportData.add(new ReportData(entry.getValue(), entry.getKey(), null));
            }
            
            countryTable.setItems(reportData);
            // Sort country table by count in descending order
            countryTable.getSortOrder().add(apptCountCol);
            apptCountCol.setSortType(TableColumn.SortType.DESCENDING);
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to generate country report: " + e.getMessage());
            alert.showAndWait();
        }
    }

    /** 
     * Handles the Generate Details button action.
     * Displays text entity details of appointments, customers, and contacts.
     * Demonstrates polymorphism by displaying details of different entity types.
     */
    @FXML
    private void generateTextReportHandler() {
    detailsArea.clear();
    try {
        List<Appointments> appointments = AppointmentDB.getAllAppointments();
        List<Customers> customers = CustomerDB.getAllCustomers();
        List<Contacts> contacts = ContactDB.getAllContacts();
        
        List<IdentifiableEntity> entities = new ArrayList<>();
        
        entities.addAll(appointments);

        entities.addAll(customers);

        entities.addAll(contacts);
        
        detailsArea.appendText("== Appointments, Customers, and Contacts ==\n\n");
        
        if (entities.isEmpty()) {
            detailsArea.appendText("No data available.");
            return;
        }
        
        // Display all entities
        for (IdentifiableEntity entity : entities) {
            detailsArea.appendText(entity.getDetails() + "\n\n");
        }
        
        // Add a summary
        detailsArea.appendText(String.format(
            "\n== Total Summary ==\n" +
            "Total Appointments: %d\n" +
            "Total Customers: %d\n" +
            "Total Contacts: %d\n" +
            "Total Entities: %d",
            appointments.size(),
            customers.size(),
            contacts.size(),
            entities.size()
        ));
        
    } catch (SQLException e) {
        detailsArea.appendText("Error summarizing data: " + e.getMessage());
    }
    }

    /**
     * Handles the Back button action.
     * Navigates back to the main menu screen. 
     * 
     * @param event menuButton clicked
     */
    @FXML
    void menuButtonHandler(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/MenuScreen.fxml"));
            Stage stage = (Stage) menuButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Main Menu");
            stage.show();
        } catch (IOException e) {
            System.out.println("Failed to load Menu Screen: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Exit Handler to exit the application with English or French translation.
     */
    @FXML
    void exitButtonHandler() {
        ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(rb.getString("confirmation"));
        alert.setHeaderText(null);
        alert.setContentText(rb.getString("quitAlert"));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }
}