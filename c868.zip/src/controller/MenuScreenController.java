package controller;

import helper.JDBC;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * MenuScreenController class to create the menu screen UI and functionality.
 */

public class MenuScreenController {

    // Menu Screen UI Components
    @FXML private Button appointmentsButton;
    @FXML private Button customersButton;
    @FXML private Button reportsButton;
    @FXML private Button exitButton;

    /**
     * Handler for appointments button. Switches to appointments screen.
     * @throws IOException
     */
    @FXML
    void appointmentsButtonHandler() throws IOException {

        Stage stage = (Stage) appointmentsButton.getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setTitle("Appointments");
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * Handler for customers button. Switches to customers screen.
     * @throws IOException
     */
    @FXML
    void customersButtonHandler() throws IOException {

        Stage stage = (Stage) customersButton.getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/view/Customers.fxml"));
        stage.setTitle("Customers");
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * Handler for reports button. Switches to reports screen.
     * @throws IOException
     */
    @FXML
    void reportsButtonHandler() throws IOException {

        Stage stage = (Stage) reportsButton.getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/view/Reports.fxml"));
        stage.setTitle("Reports");
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * Exit Handler to exit the application with English or French translation.
     */
    @FXML
    void exitButtonHandler() {
        ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(rb.getString("quitAlert"));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }
}


