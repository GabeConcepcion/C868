package controller;

import DAO.CountryDB;
import DAO.CustomerDB;
import DAO.DivisionDB;
import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import model.Country;
import model.Customers;
import model.FirstLevelDivision;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * CustomersController class to create the customers screen UI and functionality.
 * Handles creating, reading, updating, and deleting customer information
 * with associated address and division data.
 */
public class CustomersController implements Initializable {

    // Table View and Columns
    @FXML private TableView<Customers> customerTable;
    @FXML private TableColumn<Customers, Integer> customerIdCol;
    @FXML private TableColumn<Customers, String> customerNameCol;
    @FXML private TableColumn<Customers, String> customerAddressCol;
    @FXML private TableColumn<Customers, String> customerPostalCol;
    @FXML private TableColumn<Customers, String> customerPhoneCol;
    @FXML private TableColumn<Customers, String> customerDivisionCol;

    // Form Fields
    @FXML private TextField customerIdField;
    @FXML private TextField customerNameField;
    @FXML private TextField customerAddressField;
    @FXML private TextField customerPostalField;
    @FXML private TextField customerPhoneField;
    @FXML private ComboBox<Country> countryComboBox;
    @FXML private ComboBox<FirstLevelDivision> divisionComboBox;
    @FXML private TextField searchField;

    // Main Action Buttons
    @FXML private Button addButton;
    @FXML private Button modifyButton;
    @FXML private Button deleteButton;
    @FXML private Button saveButton;
    @FXML private Button cancelButton;
    @FXML private Button menuButton;

    private ObservableList<Country> allCountries;
    private ObservableList<FirstLevelDivision> allDivisions;
    private ObservableList<Customers> allCustomers; // Store all customers for filtering

    private Customers selectedCustomer = null;
    private boolean isUpdateMode = false; // Adding or updating

    /**
     * Initializes the CustomersController class.
     * Populates the customer table and combo boxes.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Setup Customer Table Columns
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerAddressCol.setCellValueFactory(new PropertyValueFactory<>("customerAddress"));
        customerPostalCol.setCellValueFactory(new PropertyValueFactory<>("customerPostalCode"));
        customerPhoneCol.setCellValueFactory(new PropertyValueFactory<>("customerPhone"));
        customerDivisionCol.setCellValueFactory(new PropertyValueFactory<>("divisionName"));

        // Load data
        loadCustomerTable();
        loadCountries();
        loadAllDivisions();

        // Set initial state for form fields (disabled until Add/Update is clicked)
        setFormFieldsDisabled(true);

        // Add event handler for search field
        searchField.setOnKeyReleased(this::searchCustomers);
    }

    /**
     * Loads all customers from the database and populates the TableView.
     */
    private void loadCustomerTable() {
        allCustomers = CustomerDB.getAllCustomers();
        customerTable.setItems(allCustomers);
    }

    /**
     * Loads all countries into the country ComboBox.
     * Sets up a StringConverter to properly display country names.
     */
    private void loadCountries() {
        allCountries = CountryDB.getAllCountries();

        countryComboBox.setItems(allCountries);
        countryComboBox.setConverter(new javafx.util.StringConverter<Country>() {
            @Override
            public String toString(Country country) {
                return country == null ? "" : country.getCountryName();
            }

            @Override
            public Country fromString(String string) {
                return countryComboBox.getItems().stream().filter(c ->
                    c.getCountryName().equals(string)).findFirst().orElse(null);
            }
        });
    }

    /**
     * Loads all divisions. Used for initial population and finding division by ID.
     * Sets up a StringConverter to properly display division names.
     */
     private void loadAllDivisions() {
         allDivisions = DivisionDB.getAllDivisions();
         divisionComboBox.setConverter(new javafx.util.StringConverter<FirstLevelDivision>() {
             @Override
             public String toString(FirstLevelDivision division) {
                 return division == null ? "" : division.getDivisionName();
             }

             @Override
             public FirstLevelDivision fromString(String string) {
                 return divisionComboBox.getItems().stream().filter(d ->
                     d.getDivisionName().equals(string)).findFirst().orElse(null);
             }
         });
     }

    /**
     * Handles the search functionality for customers.
     * Filters the customer table based on the search text (ID or name).
     * @param event Key release event from the search field
     */
    @FXML
    private void searchCustomers(KeyEvent event) {
        String searchText = ((TextField) event.getSource()).getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            customerTable.setItems(allCustomers);
            return;
        }
        
        ObservableList<Customers> filteredList = FXCollections.observableArrayList();
        
        for (Customers customer : allCustomers) {
            // Check if ID or name contains the search text (case-insensitive)
            if (String.valueOf(customer.getId()).contains(searchText) || 
                customer.getCustomerName().toLowerCase().contains(searchText)) {
                filteredList.add(customer);
            }
        }
        
        customerTable.setItems(filteredList);
    }
    /**
     * Handles the selection of a country in the ComboBox.
     * Filters the division ComboBox based on the selected country.
     * 
     * @param event countryComboBox clicked
     */
    @FXML
    void countrySelectedHandler(ActionEvent event) {
        Country selectedCountry = countryComboBox.getSelectionModel().getSelectedItem();
        
        if (selectedCountry != null) {
            // Clear the current selection first
            divisionComboBox.getSelectionModel().clearSelection();
            // Clear the items to prevent any lingering references
            divisionComboBox.setItems(FXCollections.observableArrayList());
            
            // Load the new divisions
            ObservableList<FirstLevelDivision> filteredDivisions = 
                DivisionDB.getDivisionsByCountry(selectedCountry.getCountryID());
            divisionComboBox.setItems(filteredDivisions);
            divisionComboBox.setDisable(false);
        } else {
            // No country selected, clear and disable division combo
            divisionComboBox.setItems(FXCollections.observableArrayList());
            divisionComboBox.getSelectionModel().clearSelection();
            divisionComboBox.setDisable(true);
        }
    }

    /**
     * Handles the Add Customer button action.
     * Clears the form fields and enables them for input.
     * 
     * @param event addButton clicked
     */
    @FXML
    void addCustomerHandler(ActionEvent event) {
        isUpdateMode = false;
        selectedCustomer = null;
        clearFormFields();
        setFormFieldsDisabled(false);
        customerIdField.setText("Auto-Generated"); // Indicate ID is auto-gen
        customerIdField.setDisable(true); // Ensure ID field remains disabled
        countryComboBox.getSelectionModel().clearSelection();
        divisionComboBox.getSelectionModel().clearSelection();
        divisionComboBox.setDisable(true); // Disable division until country is selected
        customerNameField.requestFocus(); // Set focus to the first editable field
    }

    /**
     * Handles the Modify Customer button action.
     * Populates the form fields with the selected customer's data.
     * Uses Optional to handle the case when no customer is selected.
     * 
     * Lambda Justification:
     * 
     * Lambda:
     *  customer -> {
                    selectedCustomer = customer;
                    isUpdateMode = true;
                    setFormFieldsDisabled(false);
                    populateFormFields(customer);
                    customerIdField.setDisable(true);
                },
                // If no customer is selected, alert
                () -> {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("No Selection");
                    alert.setHeaderText(null);
                    alert.setContentText("Please select a customer to update.");
                    alert.showAndWait();
                }
     * 
     * Purpose: The ifPresentOrElse method is used with a lambda to handle
     * if a customer is selected or not.
     * If selected: Enable and populate form fields with customer data
     * If not selected: Show an alert
     * 
     * Reason: The lambda expressions make the code more concise than a nested if-else.
     * 
     * @param event modifyButton clicked
     */
    @FXML
    void modifyCustomerHandler(ActionEvent event) {
        Optional.ofNullable(customerTable.getSelectionModel().getSelectedItem())
            .ifPresentOrElse(
                // If customer is selected, populate form fields
                customer -> {
                    selectedCustomer = customer;
                    isUpdateMode = true;
                    setFormFieldsDisabled(false);
                    populateFormWithCustomer(customer);
                    customerIdField.setDisable(true);
                },
                // If no customer is selected, alert
                () -> {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("No Selection");
                    alert.setHeaderText(null);
                    alert.setContentText("Please select a customer to update.");
                    alert.showAndWait();
                }
            );
    }

    /**
     * Handles the Delete Customer button action.
     * Deletes the selected customer and any associated appointments.
     * 
     * @param event deleteButton clicked
     */
    @FXML
    void deleteCustomerHandler(ActionEvent event) throws SQLException {
        Customers customerToDelete = customerTable.getSelectionModel().getSelectedItem();
        if (customerToDelete != null) {
            // Confirmation Dialog
            Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmAlert.setTitle("Confirm Deletion");
            confirmAlert.setHeaderText("Delete Customer: " + customerToDelete.getCustomerName());
            confirmAlert.setContentText("This will delete the customer and all associated appointments.\n\nAre you sure you want to continue?");
            
            Optional<ButtonType> result = confirmAlert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                try {
                    // Delete the customer and associated appointments
                    if (CustomerDB.deleteCustomer(customerToDelete.getId())) {
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                        successAlert.setTitle("Success");
                        successAlert.setHeaderText(null);
                        successAlert.setContentText("Customer and all associated appointments have been deleted successfully.");
                        successAlert.showAndWait();
                        
                        // Refresh table
                        loadCustomerTable();
                        clearFormFields();
                        setFormFieldsDisabled(true);
                    } else {
                        // Show error message if deletion failed
                        Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                        errorAlert.setTitle("Error");
                        errorAlert.setHeaderText(null);
                        errorAlert.setContentText("Failed to delete the customer.");
                        errorAlert.showAndWait();
                    }
                } catch (SQLException e) {
                    // Show error message with details from the exception
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Database Error");
                    errorAlert.setHeaderText("Error deleting customer");
                    errorAlert.setContentText("An error occurred while deleting the customer: " + e.getMessage());
                    errorAlert.showAndWait();
                    e.printStackTrace();
                }
            }
        } else {
            // No customer selected
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText(null);
            alert.setContentText("Please select a customer to delete.");
            alert.showAndWait();
        }
    }

    /**
     * Populates form fields with the selected customer's information.
     * 
     * @param customer customer information for form.
     */
    private void populateFormWithCustomer(Customers customer) {
        customerIdField.setText(String.valueOf(customer.getId()));
        customerNameField.setText(customer.getCustomerName());
        customerAddressField.setText(customer.getCustomerAddress());
        customerPostalField.setText(customer.getCustomerPostalCode());
        customerPhoneField.setText(customer.getCustomerPhone());
    
        // Find and select the correct country and division
        FirstLevelDivision customerDivision = findDivisionById(customer.getDivisionID());
        if (customerDivision != null) {
            Country customerCountry = findCountryById(customerDivision.getDivisionCountryID());
            if (customerCountry != null) {
                // Select country
                countryComboBox.getSelectionModel().select(customerCountry);
                
                // Get and set divisions for the selected country
                ObservableList<FirstLevelDivision> filteredDivisions = DivisionDB.getDivisionsByCountry(customerCountry.getCountryID());
                divisionComboBox.setItems(filteredDivisions);
                
                // Select division
                divisionComboBox.getSelectionModel().select(customerDivision);
                divisionComboBox.setDisable(false);
            }
        }
    }

    /**
     * Handler for the Save Customer button action.
     * Validates input and adds or updates a customer.
     * 
     * @param event saveButton clicked
     */
   @FXML
    void saveButtonHandler(ActionEvent event) {
        // Validate input fields
        if (!validateInput()) return;

        try {
            // Create customer from form data
            String name = customerNameField.getText();
            String address = customerAddressField.getText();
            String postalCode = customerPostalField.getText();
            String phone = customerPhoneField.getText();

            FirstLevelDivision selectedDivision = divisionComboBox.getSelectionModel().getSelectedItem();

            if (selectedDivision == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Validation Error");
                alert.setHeaderText(null);
                alert.setContentText("Please select a first-level division.");
                alert.showAndWait();
                return;
            }
            int divisionId = selectedDivision.getDivisionID();

            if (isUpdateMode && selectedCustomer != null) {
                // Update existing customer
                selectedCustomer.setCustomerName(name);
                selectedCustomer.setCustomerAddress(address);
                selectedCustomer.setCustomerPostalCode(postalCode);
                selectedCustomer.setCustomerPhone(phone);
                selectedCustomer.setDivisionID(divisionId);
                // Update divisionName based on selectedDivision (optional, depends if needed elsewhere)
                selectedCustomer.setDivisionName(selectedDivision.getDivisionName());

                if (CustomerDB.updateCustomer(selectedCustomer)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Update Successful");
                    alert.setHeaderText(null);
                    alert.setContentText("Customer updated successfully. If the Country was modified without updating the Division, the original Division and Country will be used.");
                    alert.showAndWait();
                    loadCustomerTable();
                    clearFormFields();
                    setFormFieldsDisabled(true);
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Update Failed");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to update customer.");
                    alert.showAndWait();
                }
            } else {
                // Create new customer
                Customers newCustomer = new Customers(0, name, address, postalCode, phone, divisionId, ""); // Temp division name
                if (CustomerDB.addCustomer(newCustomer)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Customer created successfully.");
                    alert.showAndWait();
                    loadCustomerTable();
                    clearFormFields();
                    setFormFieldsDisabled(true);
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to create customer.");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            System.err.println("Error in saveButtonHandler: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            if (e.getMessage() != null) e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Save Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to save customer: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
            alert.showAndWait();
        }
    }

    /**
     * Validates the input fields for the customer form.
     * 
     * @return True if all required fields are filled, false otherwise.
     */
    private boolean validateInput() {
        StringBuilder errors = new StringBuilder();
        if (customerNameField == null || customerNameField.getText().trim().isEmpty()) errors.append("Name is required.\n");
        if (customerAddressField == null || customerAddressField.getText().trim().isEmpty()) errors.append("Address is required.\n");
        if (customerPostalField == null || customerPostalField.getText().trim().isEmpty()) errors.append("Postal Code is required.\n");
        if (customerPhoneField == null || customerPhoneField.getText().trim().isEmpty()) errors.append("Phone is required.\n");
        if (countryComboBox == null || countryComboBox.getValue() == null) errors.append("Country is required.\n");
        if (divisionComboBox == null || divisionComboBox.getValue() == null) errors.append("Division is required.\n");
    
        if (errors.length() > 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString().trim());
            alert.showAndWait();
            return false;
        }
        return true;
    }

    /**
     * Handles the Cancel button action.
     * Clears the form and disables fields.
     */
    @FXML
    void cancelButtonHandler(ActionEvent event) {
        clearFormFields();
        setFormFieldsDisabled(true);
        selectedCustomer = null;
        isUpdateMode = false;
        customerTable.getSelectionModel().clearSelection(); // Clear table selection
    }

    /**
     * Clears all gridpane form fields.
     */
    private void clearFormFields() {
        customerIdField.clear();
        customerNameField.clear();
        customerAddressField.clear();
        customerPostalField.clear();
        customerPhoneField.clear();
        countryComboBox.getSelectionModel().clearSelection();
        divisionComboBox.setItems(FXCollections.observableArrayList()); // Clear division items
        divisionComboBox.getSelectionModel().clearSelection();
        divisionComboBox.setDisable(true); // Disable division combo box initially
    }

    /**
     * Disables or enables all gridpane form fields based on the disable parameter.
     * Customer ID field is always disabled.
     * 
     * @param disable True to disable fields, false to enable.
     */
    private void setFormFieldsDisabled(boolean disable) {
        // Customer ID field is always disabled
        customerIdField.setDisable(true);
        customerNameField.setDisable(disable);
        customerAddressField.setDisable(disable);
        customerPostalField.setDisable(disable);
        customerPhoneField.setDisable(disable);
        countryComboBox.setDisable(disable);
        divisionComboBox.setDisable(disable || countryComboBox.getSelectionModel().isEmpty()); // Also disable if no country selected
        saveButton.setDisable(disable);
        cancelButton.setDisable(disable);
    }
    
    /**
     * Finds a Country object by its ID from the loaded list.
     * @param countryId The ID of the country to find.
     * @return The Country object, or null if not found.
     */
    private Country findCountryById(int countryId) {
        return allCountries.stream()
                           .filter(c -> c.getCountryID() == countryId)
                           .findFirst()
                           .orElse(null);
    }

    /**
     * Finds a FirstLevelDivision object by its ID from the loaded list.
     * @param divisionId The ID of the division to find.
     * @return The FirstLevelDivision object, or null if not found.
     */
    private FirstLevelDivision findDivisionById(int divisionId) {
         return allDivisions.stream()
                           .filter(d -> d.getDivisionID() == divisionId)
                           .findFirst()
                           .orElse(null);
    }

    /**
     * Handles the Back button action.
     * Navigates back to the main menu screen.
     */
    @FXML
    void menuButtonHandler(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/MenuScreen.fxml"));
            Stage stage = (Stage) menuButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Main Menu");
            stage.show();
        } catch (IOException e) {
            System.out.println("Failed to load Menu Screen: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Handler to exit the application with English or French translation.
     */
    @FXML
    void exitButtonHandler() {
        ResourceBundle rb = ResourceBundle.getBundle("language/language", Locale.getDefault());
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(rb.getString("confirmation"));
        alert.setHeaderText(null);
        alert.setContentText(rb.getString("quitAlert"));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }
}
