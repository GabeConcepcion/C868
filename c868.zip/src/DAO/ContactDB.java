package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contacts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * ContactDB class to handle database operations for Contact objects.
 * Provides methods to retrieve contact information from the database.
 */
public class ContactDB {

    /**
     * Retrieves all contacts from the database.
     * Populates contact selection ComboBoxes.
     * 
     * @return ObservableList of all contacts.
     * @throws SQLException if a database access error occurs.
     */
    public static ObservableList<Contacts> getAllContacts() throws SQLException {
        ObservableList<Contacts> contactsList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM contacts";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String email = rs.getString("Email");
                Contacts contact = new Contacts(contactID, contactName, email);
                contactsList.add(contact);
            }
        } catch (SQLException e) {
            System.err.println("Error getting contacts: " + e.getMessage());
            e.printStackTrace();
        }
        return contactsList;
    }
}
