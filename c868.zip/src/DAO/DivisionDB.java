package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FirstLevelDivision;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DivisionDB class to handle database operations for FirstLevelDivision objects.
 * Provides methods to retrieve first-level divisions and filter by country.
 */
public class DivisionDB {

    /**
     * Retrieves first-level divisions from the database.
     * Populates division selection ComboBoxes.
     * 
     * @return ObservableList of all FirstLevelDivision objects.
     */
    public static ObservableList<FirstLevelDivision> getAllDivisions() {
        ObservableList<FirstLevelDivision> divisionList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM first_level_divisions";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                FirstLevelDivision division = new FirstLevelDivision(divisionID, divisionName, countryID);
                divisionList.add(division);
            }
        } catch (SQLException e) {
            System.out.println("Error getting all divisions: " + e.getMessage());
            e.printStackTrace();
        }
        return divisionList;
    }

    /**
     * Retrieves first-level divisions filtered by Country ID.
     * Populates division selection ComboBoxes based on selected country.
     * 
     * @param countryId country ID to filter by.
     * @return ObservableList of FirstLevelDivision objects for the selected country.
     */
    public static ObservableList<FirstLevelDivision> getDivisionsByCountry(int countryId) {
        ObservableList<FirstLevelDivision> divisionList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = ?";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setInt(1, countryId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                FirstLevelDivision division = new FirstLevelDivision(divisionID, divisionName, countryID);
                divisionList.add(division);
            }
        } catch (SQLException e) {
            System.out.println("Error getting divisions by country: " + e.getMessage());
            e.printStackTrace();
        }
        return divisionList;
    }
}
